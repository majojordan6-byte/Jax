# MAJO TRADING INTELLIGENCE — Step 1 scaffold

This repository is **Step 1 only**: a FastAPI service, Next.js 15 dark dashboard,
PostgreSQL/TimescaleDB, Redis, and Docker Compose.

The dashboard intentionally shows **DATA SOURCE NOT CONNECTED**. No prices,
candles, demo values, indicators, signals, or order execution are implemented.

## Run in GitHub Codespaces

1. Open your GitHub repository in Codespaces.
2. Upload/extract this project into the repository root (the folder containing
   `docker-compose.yml`).
3. Open **Terminal → New Terminal**.
4. Run:

   ```bash
   docker compose up --build -d
   ```

   This builds the two app images and starts the database, Redis, API, and web
   services in the background.

5. Check service state:

   ```bash
   docker compose ps
   ```

   Wait until the services report `healthy`.

6. In Codespaces, open the **Ports** tab and open port **3000**. The dashboard
   should show a red `DATA SOURCE NOT CONNECTED` banner.

7. Check the API directly in the terminal:

   ```bash
   curl http://localhost:8000/health
   ```

   Expected shape (timestamps and service statuses can vary):

   ```json
   {
     "status": "healthy",
     "services": {
       "postgres": "CONNECTED",
       "redis": "CONNECTED"
     },
     "market_data": {
       "status": "NOT_CONNECTED",
       "provider": null,
       "missing_environment_variables": [
         "MTI_LSE_DATA_API_KEY",
         "MTI_FCSAPI_API_KEY"
       ]
     }
   }
   ```

   `healthy` means the app can reach its database and Redis. It does **not**
   mean a market-data provider is connected.

## Stop the services

```bash
docker compose down
```

To also delete the local database volume (this permanently removes its data):

```bash
docker compose down -v
```

Do not run the second command unless you intentionally want to erase the
development database.

## Step 1 boundaries

- No market-data adapter is implemented yet (that is Step 3).
- No indicators or signal engine are implemented yet (Steps 2 and 4).
- No broker connection, order endpoint, or trade execution exists.
- No sample/demo market prices are generated.
- API credentials are not required and should never be placed in frontend files.
- The health endpoint reports missing provider environment variables without
  exposing credential values.

## Troubleshooting

- If `docker compose` says Docker is unavailable, check that the Codespace was
  created with Docker support and that its Docker service is running. Do not
  try to run Docker on the Android phone itself.
- If a port is private, use the Ports tab to change its visibility only if
  needed. Keep the project private unless you intentionally want to share it.
- If a container is unhealthy, inspect its logs:

  ```bash
  docker compose logs api
  docker compose logs web
  docker compose logs db
  docker compose logs redis
  ```
