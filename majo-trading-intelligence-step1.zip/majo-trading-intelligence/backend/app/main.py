from datetime import datetime, timezone
from typing import Any

import asyncpg
from fastapi import FastAPI
from redis.asyncio import Redis
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    database_url: str = "postgresql://mti:local-dev-only-change-me@db:5432/mti"
    redis_url: str = "redis://redis:6379/0"
    mti_lse_data_api_key: str = ""
    mti_fcsapi_api_key: str = ""
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")


settings = Settings()
app = FastAPI(
    title="MAJO TRADING INTELLIGENCE API",
    version="0.1.0",
    description="Step 1 scaffold. No market data or trading execution.",
)


async def check_postgres() -> str:
    try:
        conn = await asyncpg.connect(settings.database_url, timeout=2)
        try:
            await conn.fetchval("SELECT 1")
        finally:
            await conn.close()
        return "CONNECTED"
    except Exception:
        return "DISCONNECTED"


async def check_redis() -> str:
    client = Redis.from_url(settings.redis_url, socket_connect_timeout=2)
    try:
        return "CONNECTED" if await client.ping() else "DISCONNECTED"
    except Exception:
        return "DISCONNECTED"
    finally:
        await client.aclose()


@app.get("/")
async def root() -> dict[str, str]:
    return {
        "name": "MAJO TRADING INTELLIGENCE",
        "phase": "STEP_1_SCAFFOLD",
        "message": "No market data or trading execution is implemented.",
    }


@app.get("/health")
async def health() -> dict[str, Any]:
    postgres, redis = await check_postgres(), await check_redis()
    db_redis_healthy = postgres == "CONNECTED" and redis == "CONNECTED"

    missing = []
    if not settings.mti_lse_data_api_key:
        missing.append("MTI_LSE_DATA_API_KEY")
    if not settings.mti_fcsapi_api_key:
        missing.append("MTI_FCSAPI_API_KEY")

    # Keys alone do not prove provider connectivity. Step 3 will implement
    # authenticated provider probes. Until then, market data remains disconnected.
    return {
        "status": "healthy" if db_redis_healthy else "degraded",
        "checked_at_utc": datetime.now(timezone.utc).isoformat(),
        "services": {"postgres": postgres, "redis": redis},
        "market_data": {
            "status": "NOT_CONNECTED",
            "provider": None,
            "missing_environment_variables": missing,
            "note": "Provider connectivity is not implemented until Step 3.",
        },
        "trading": {
            "execution_enabled": False,
            "note": "This build is analysis-only. No order endpoints exist.",
        },
    }
