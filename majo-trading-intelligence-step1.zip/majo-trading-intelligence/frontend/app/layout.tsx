import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "MAJO TRADING INTELLIGENCE",
  description: "Personal market analysis terminal"
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
