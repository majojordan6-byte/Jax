import { headers } from "next/headers";

type Health = {
  status?: string;
  checked_at_utc?: string;
  services?: { postgres?: string; redis?: string };
  market_data?: {
    status?: string;
    provider?: string | null;
    missing_environment_variables?: string[];
    note?: string;
  };
  trading?: { execution_enabled?: boolean };
};

async function getHealth(): Promise<Health | null> {
  try {
    const h = await headers();
    const host = h.get("host") ?? "localhost:3000";
    const protocol = h.get("x-forwarded-proto") ?? "http";
    const base = process.env.API_INTERNAL_URL ?? `${protocol}://${host}`;
    const response = await fetch(`${base}/health`, { cache: "no-store" });
    if (!response.ok) return null;
    return await response.json();
  } catch {
    return null;
  }
}

export const dynamic = "force-dynamic";

export default async function Home() {
  const health = await getHealth();
  const connected = health?.market_data?.status === "CONNECTED";

  return (
    <main className="shell">
      <header className="topbar">
        <div>
          <div className="eyebrow">PERSONAL MARKET TERMINAL</div>
          <h1>MAJO <span>TRADING INTELLIGENCE</span></h1>
        </div>
        <div className="terminal-tag">STEP 01 / SCAFFOLD</div>
      </header>

      <section className={`data-alert ${connected ? "connected" : ""}`} role="status">
        <span className="alert-dot" />
        <div>
          <strong>{connected ? "MARKET DATA CONNECTED" : "DATA SOURCE NOT CONNECTED"}</strong>
          <p>{connected
            ? "Provider reports a connection. No live chart is implemented in Step 1."
            : "No verified market feed is available. Prices and candles are intentionally hidden."}</p>
        </div>
      </section>

      <section className="grid">
        <article className="panel status-panel">
          <div className="panel-title">SYSTEM STATUS</div>
          <Status label="API" value={health ? "REACHABLE" : "UNAVAILABLE"} good={!!health} />
          <Status label="POSTGRES / TIMESCALEDB" value={health?.services?.postgres ?? "UNKNOWN"} good={health?.services?.postgres === "CONNECTED"} />
          <Status label="REDIS" value={health?.services?.redis ?? "UNKNOWN"} good={health?.services?.redis === "CONNECTED"} />
          <Status label="MARKET DATA" value={health?.market_data?.status ?? "UNKNOWN"} good={connected} />
          <Status label="TRADE EXECUTION" value="DISABLED" good={false} />
          <div className="timestamp">
            Health check (UTC): {health?.checked_at_utc ?? "Not available"}
          </div>
        </article>

        <article className="panel empty-panel">
          <div className="panel-title">MARKET OVERVIEW</div>
          <div className="empty-state">
            <div className="empty-icon">—</div>
            <h2>NO VERIFIED MARKET DATA</h2>
            <p>Live instruments, prices, and charts will appear only after a real provider is connected and verified.</p>
          </div>
        </article>

        <article className="panel notice-panel">
          <div className="panel-title">BUILD STATUS</div>
          <div className="build-row"><span>Current step</span><b>01 — SCAFFOLD</b></div>
          <div className="build-row"><span>Indicators</span><b className="muted">NOT BUILT</b></div>
          <div className="build-row"><span>Signal engine</span><b className="muted">NOT BUILT</b></div>
          <div className="build-row"><span>Broker orders</span><b className="muted">NOT PRESENT</b></div>
          <p className="risk">RISK NOTICE: This terminal is informational software, not financial advice. No strategy performance has been established. Trading involves risk, including loss.</p>
        </article>
      </section>
      <footer>MAJO TRADING INTELLIGENCE <span>HONEST DATA · NO PLACEHOLDERS · NO ORDER EXECUTION</span></footer>
    </main>
  );
}

function Status({ label, value, good }: { label: string; value: string; good: boolean }) {
  return <div className="status-row">
    <span>{label}</span>
    <b className={good ? "good" : "bad"}>{value}</b>
  </div>;
}
